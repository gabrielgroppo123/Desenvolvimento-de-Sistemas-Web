import express from 'express';

export default function adicionarRotas(api) {

    api.use('/public/storage/capa', express.static('public/storage/capa'));
}